# RESEARCH_MASTER.md
## Authoritative research reference — PNG Financial Markets eBook

**Version:** Reconstructed working version 1.0  
**Research baseline:** 4 October 2026  
**Status:** Consolidated working reference; not fully source-audited  
**Repository:** `JennyJoshua/png-financial-markets-ebook`

> **Provenance warning:** This is a reconstructed replacement based on research findings preserved in project context. It is not the recovered original `RESEARCH_MASTER.md`, and it does not mean every underlying report has been re-opened. Treat time-sensitive figures as leads until checked against exact source documents.

## 1. Purpose and authority

This is the central research reference for a free, downloadable eBook explaining financial markets with a particular focus on Papua New Guinea. Its main audiences are PNG secondary students and the general public. It is general education, not a formal school textbook, official government publication, investment prospectus or personalised financial advice.

Consult original sources for important claims. This master does not override primary-source evidence or project-owner approval.

## 2. How to use this master

- Use the latest authoritative source for current facts.
- Preserve reference periods, definitions and units.
- Mark values as actual, provisional, estimate or forecast.
- Never turn a forecast into an actual result.
- Do not infer that missing evidence proves a claim false.
- Never invent source titles, dates, page numbers, legal interpretations or URLs.
- Record unresolved questions in the controlled claims table and G01–G19 register.
- Obtain owner approval before moving to architecture, detailed outline and chapter drafting.

## 3. Evidence hierarchy

1. **Primary official sources:** BPNG, PNG Treasury, NSO, SCPNG, PNGX, relevant PNG regulators and official legal sources; IMF, World Bank and WTO for their own publications/data.
2. **High-quality secondary sources:** peer-reviewed research, credible research institutions and established reporting that identifies its evidence.
3. **Supporting sources:** industry commentary and educational material.

When sources conflict, compare publication dates, reference periods, definitions, geographic coverage and methodology. Preserve unresolved discrepancies rather than quietly choosing a convenient figure.

## 4. Statistical and citation standards

For each important statistic record the indicator, value, unit/currency, geographic scope, reference period, publication date, exact source title and URL, page/table where available, status (actual/provisional/estimate/forecast), definition and caveats. Do not mix quarterly and annual datasets as though identical. Do not compare nominal and real values without explanation. Registered accounts are not automatically unique people or active users.

## 5. Financial-market fundamentals

Financial markets are systems and arrangements in which financial assets and claims are issued, bought, sold, priced or transferred. They connect savers and borrowers, allocate capital, support price discovery, provide liquidity and transfer or redistribute some risks.

Core terms:
- **Financial asset:** a claim such as a bank deposit, share or bond.
- **Saving:** setting money aside for security or a goal.
- **Investing:** committing money to an asset/activity with uncertain future outcomes.
- **Return:** income and/or change in value over a stated period.
- **Risk:** possibility that outcomes differ from expectations, including loss.
- **Liquidity:** how readily an asset can be converted to money without substantial loss.
- **Diversification:** spreading exposure to reduce some risks, not eliminate all risks.
- **Inflation:** rise in the general price level.
- **Nominal return:** return before inflation adjustment.
- **Real return:** return adjusted for purchasing-power changes.
- **Compounding:** returns generating further returns; losses and fees also affect outcomes.
- **Price discovery:** process by which buyers and sellers establish prices.
- **Capital allocation:** movement of funds to borrowers, issuers and opportunities.

Risk types include market, credit, liquidity, interest-rate, inflation, foreign-exchange, concentration, operational and fraud/scam risk. Markets do not guarantee wealth and returns must not be described as guaranteed.

## 6. PNG financial-system map

Explain the roles and relationships of BPNG, commercial banks, other licensed financial institutions, savings and loan societies, PNGX, SCPNG, Treasury/government securities, superannuation funds, insurers, payment-service providers, households, businesses, savers, borrowers, investors and international markets.

Keep distinct: central bank/commercial bank; exchange/regulator; deposit/share; government security/company share; depositor protection/deposit insurance; payment service/banking licence.

## 7. BPNG and monetary policy

BPNG's primary monetary-policy objective is price stability, with broader responsibilities relating to financial stability, sustainable growth and development of the financial system.

Baseline findings:
- March 2026 KFR: **5.0%**.
- March 2026 CRR: **9.0%**.
- BPNG September 2026 outlook projected inflation around **4%**.

These are dated findings and must be checked against exact official releases. The inflation figure is a forecast, not a full-year actual. Policy rates do not mechanically determine every deposit or lending rate.

## 8. Macroeconomic outlook

Baseline figures requiring exact source-level confirmation:
- IMF 2026 real GDP growth projection around **3.8%**.
- Research notes record around **5.6%** for 2025; verify whether forecast or result.
- IMF 2026 headline inflation projection around **4.8%**.
- BPNG September 2026 inflation outlook around **4%**.
- BPNG outlook projected end-2026 reserves around **US$4.4 billion**.
- 2026 Budget projected end-2026 public debt at **K66.2157 billion**, or **45.5% of GDP**.

The end-2026 values are projections unless final actual data are verified. Record report, date, definition and period for every figure.

## 9. Foreign exchange and the kina

Explain foreign-currency demand and supply, imports/exports, exchange rates and reserves, and impacts on businesses and households.

Research notes say IMF material described PNG's exchange-rate arrangement as **crawl-like**. They also record improved FX access during the period covered, associated with reforms, reduced kina overvaluation and stronger commodity prices. Verify current conditions and do not claim shortages have permanently disappeared.

Foreign reserves are not the same as government revenue, total exports or money freely available for any spending purpose.

## 10. Commodity dependence and trade

Baseline findings:
- WTO material reported energy and mineral products were more than **77% of PNG exports in 2024**.
- WTO material reported a commodity-dependence index around **97%**.
- BPNG March-quarter 2024 merchandise exports: **K11,334.0 million**.
- Mineral products including LNG and condensate: **K9,958.5 million**, around **87.9%** of that quarterly total.
- World Bank material reported a current-account surplus around **15.1% of GDP in 2024**, driven by mineral exports after Porgera reopened and high copper/gold prices.

Verify exact documents and definitions. Annual WTO measures and quarterly BPNG figures are different datasets. Explain commodity exposure without implying benefits are evenly distributed.

## 11. PNGX and listed companies

PNGX is PNG's stock exchange. Research notes state it began in 1999 as the Port Moresby Stock Exchange and was renamed PNGX in December 2018.

The listed-companies page checked on 4 October 2026 showed 13 companies:
1. Adyton Resources Corporation
2. BSP Financial Group
3. City Pharmacy
4. Credit Corporation
5. Kina Asset Management
6. Kina Securities
7. Newmont Corporation
8. NGIP Argmark
9. Niuminco Group
10. Pacific Lime and Cement
11. PNG Air
12. Santos
13. Steamships Trading Company

Research notes record Adyton listing on 23 September 2026 and Pacific Lime and Cement listing on 15 December 2025. Recheck before publication.

**Market capitalisation:** PNGX's About page quoted about K138 billion but also referred to 12 companies, while the listings page showed 13. Do not call K138 billion definitively current without confirming its date and basis. SCPNG's US$20.3 billion figure from October 2021 is historical.

Research identified JMP Securities and Kina Securities in relation to investor access. Verify current authorisation before naming brokers in practical instructions. Explain share ownership, price changes, disclosures, diversification, fees, liquidity and loss risk.

## 12. Banking and licensed institutions

Research baseline dated 29 July 2025 identified seven commercial banks:
1. ANZ PNG
2. BSP Financial Group
3. Credit Corporation Finance Limited, trading as CreditBank PNG
4. Kina Securities
5. National Banking Corporation
6. TISA Bank
7. Westpac PNG

The same research identified 13 licensed financial institutions and 18 savings and loan societies. Digicel PNG Financial Services was identified as a payment service provider/inward-remittance provider.

Recheck BPNG's current list and categories. Do not state PNG has only four commercial banks. A name or group affiliation alone does not prove a current licence.

## 13. Government securities and Treasury bills

Explain government borrowing, Treasury bills versus longer-term bonds, issue price, maturity value, yield, interest-rate risk, inflation risk and liquidity. A quoted yield depends on instrument, date, maturity and calculation method.

A reliable current weighted-average Treasury bill yield was not established. Historical yields around 7.7–8.2% must not be presented as current. Use dated official BPNG data and state the basis. Do not imply all readers can access an instrument without checking eligibility and channels.

## 14. Saving, investing, risk and return

Explain emergency savings, goals and time horizons, deposits, shares, government securities, superannuation, insurance, fees, inflation, liquidity and diversification. Product suitability depends on objectives, circumstances, access, time horizon and ability to withstand loss. Do not give personalised advice or promise returns.

## 15. Financial inclusion

The National Financial Inclusion Strategy covers **2023–2027**. Priorities include women, rural and mobile/digital services, financial literacy, consumer protection and data.

Research notes report BPNG/CEFI financial-literacy training reached over **250,000 people**, including around **120,000 women**. Confirm exact report, period and counting method.

No reliable current national headline inclusion rate was established. Do not use “75% financially excluded” without exact authoritative evidence. Do not use an approximately 32% deposit-account coverage figure without source, date, population and definition. Access, ownership, active use, affordability and financial well-being are different measures.

## 16. Mobile money and digital finance

The baseline records approximately **1.47 million registered mobile-money accounts in Q4 2024**. Verify the exact source. Registered accounts are not necessarily active users, unique people or adults. Do not convert this figure into a count of people.

Discuss payments and transfers alongside connectivity, fees, fraud, impersonation, PIN security, privacy and dispute resolution.

## 17. Women's financial access

Women are a policy and programme priority, but no reliable current national percentage for women's financial access was established. Do not infer national access from programme attendance. Distinguish financial-literacy participation, account ownership, active use, credit access, asset ownership and decision-making power.

## 18. Depositor protection and deposit insurance

Research notes confirm depositor protection under banking law but do not establish a separate formal deposit-insurance scheme. The exact current legal position remains unresolved.

Do not claim either “PNG has deposit insurance” or “PNG has no depositor protection” without authoritative current evidence. Distinguish prudential regulation, legal depositor rights, lender-of-last-resort arrangements and a formal scheme with defined eligibility/payout conditions.

## 19. Cryptocurrency and virtual assets

BPNG warnings about unlicensed virtual-asset service providers and crypto investment platforms were identified. The full current legal status was not resolved. Do not claim crypto is categorically illegal or fully legal/regulated without authoritative current legal evidence. Explain volatility, custody/platform risks, scams and irreversible transfers. A warning about unlicensed providers is not automatically a ruling on all virtual-asset activity.

## 20. Foreign reserves

BPNG's September 2026 outlook reportedly projected around **US$4.4 billion** by end-2026. This is a forecast, not a final result. Check the latest actual figure and reference date. Reserves support external payments and financial stability; they are not budget revenue or money freely available for any public spending.

## 21. Public debt

The 2026 Budget reportedly projected end-2026 public debt of **K66.2157 billion**, or **45.5% of GDP**. Treat as projection unless actual results are verified. Explain domestic/external borrowing, debt service, maturities, currency and debt-to-GDP. One ratio alone does not prove debt is safe or unsustainable.

## 22. Superannuation

Research notes confirm authorised funds and Q1 2026 statistical tables, but aggregate current assets and membership were not extracted. Funds identified include Defence Force Retirement Benefit Fund, Nambawan Super, National Superannuation Fund and Pac Super.

A BPNG public notice referred to employer contributions of **8.4%** and employee contributions of **6.0%**, subject to statutory conditions. Verify applicability and legal conditions; do not present as universal. Do not invent aggregate assets, membership or returns.

## 23. Insurance

The licensed sector was identified, but aggregate current assets, premiums, claims, policyholder counts and penetration were not extracted. Do not invent figures. Explain premiums, covered events, exclusions, claims and policy terms.

## 24. Scams and consumer protection

Official warnings exist, but no reliable national scam-prevalence figure was established. Do not invent victim counts or losses. Teach warning signs: guaranteed or implausible returns, pressure to act immediately, fake institutional identities, requests for PINs/passwords/one-time codes, unverified platforms, advance fees to release supposed profits, and recruitment schemes misrepresented as investments. Encourage independent verification and reporting through official channels.

## 25. Controlled claims table

| Claim | Status | What is established | What must not be claimed | Next action |
|---|---|---|---|---|
| PNGX market cap K138bn | Unresolved | Figure appeared on About page | Not definitively current | Verify date, method and listing-count discrepancy |
| PNGX listing count | Dated; recheck | 13 shown on 4 Oct 2026 | Count may not remain current | Recheck official list |
| Current Treasury bill yields | Unresolved | Historical figures insufficient | Do not present 7.7–8.2% as current | Find dated official yield data |
| National inclusion rate | Unresolved | NFIS exists | No unsupported headline percentage | Find representative survey |
| “75% financially excluded” | Unverified | Exact authoritative source not established | Do not repeat as fact | Trace source/date/definition or omit |
| Deposit-account coverage around 32% | Unverified | Source/definition not established | Do not use without evidence | Trace original indicator |
| Mobile money around 1.47m accounts | Dated lead | Registered accounts in Q4 2024 | Not active users or unique people | Confirm official table |
| Women's national access rate | Unresolved | Policy/programme priority | No inferred national rate | Find representative sex-disaggregated data |
| Deposit insurance | Unresolved | Depositor protection noted | Neither assert scheme nor absence without evidence | Check law and notices |
| Crypto legal status | Unresolved | Warnings about unlicensed providers | No blanket legal conclusion | Review current laws/notices |
| Foreign reserves | Forecast in baseline | About US$4.4bn projected end-2026 | Not an actual result | Find latest actual data |
| Public debt/debt-to-GDP | Budget projection | K66.2157bn; 45.5% projected | Not final actual outcome | Check Treasury statement |
| Superannuation aggregates | Unresolved | Funds/tables identified | Do not invent assets/membership | Extract official tables |
| Insurance aggregates | Unresolved | Licensed sector identified | Do not invent sector totals | Extract regulator statistics |
| Scam prevalence | Unresolved | Official warnings exist | No invented national prevalence | Find official data, if any |
| Commercial-bank count | Dated; recheck | Seven as at 29 Jul 2025 | Do not state only four banks | Check current BPNG list |
| Broker authorisation | Recheck | JMP and Kina noted in research | No unverified authorisation claim | Check SCPNG/PNGX |
| Inflation, KFR, CRR | Dated/forecast | March rates and September outlook recorded | Not automatically current | Verify latest releases |
| Bonds, liquidity, fintech/Digital Kina | Partial/unresolved | Need further official research | Do not overstate current status | Find dated official data |

## 26. Research-gap register G01–G19

See `research_gap_verification_4.md` for the detailed reconstructed register. Its topics are:
- G01 market capitalisation;
- G02 turnover/liquidity;
- G03 retail participation;
- G04 brokers/investor access;
- G05 mobile money/fintech;
- G06 national inclusion;
- G07 women's access;
- G08 deposit insurance;
- G09 foreign reserves;
- G10 public debt;
- G11 Treasury bill yields;
- G12 crypto/virtual assets;
- G13 scams;
- G14 superannuation;
- G15 insurance;
- G16 IPOs/listings;
- G17 bond market;
- G18 liquidity/fintech/Digital Kina;
- G19 licensed institutions.

These reconstructed descriptions should be compared with the original register if recovered.

## 27. Provisional book architecture

This is not final or approved:
1. What Are Financial Markets?
2. Why Financial Markets Matter
3. Banks and the Banking System
4. Money, Interest Rates and Inflation
5. Foreign Exchange and the Kina
6. Shares and the PNGX
7. Bonds and Government Borrowing
8. Saving and Investing
9. Risk and Return
10. Diversification and Long-Term Thinking
11. Superannuation and Insurance
12. Digital Finance and Financial Inclusion
13. Commodities and PNG's Economy
14. Financial Scams and Consumer Protection
15. How the Financial System Connects Everything

Before drafting each chapter, identify its purpose, concepts, PNG examples, source checks and unresolved gaps. The owner must approve architecture and detailed outline separately.

## 28. Source register

These are official starting points, not proof that a specific statistic has been verified. For each source actually consulted, add exact title, publication date, reference period, page/table, claim supported and limitations.

| ID | Organisation | URL | Use and limitation |
|---|---|---|---|
| BPNG-01 | BPNG | https://www.bankpng.gov.pg/ | Entry point; locate exact report |
| BPNG-02 | BPNG | https://www.bankpng.gov.pg/financial-stability/list-licensed-institutions | Licensed institutions; recheck |
| BPNG-03 | BPNG | https://www.bankpng.gov.pg/monetary-policy | Monetary policy; recheck latest |
| BPNG-04 | BPNG | https://www.bankpng.gov.pg/monetary-policy/formulation-and-implementation-monetary-policy | Policy instruments; exact source needed |
| BPNG-05 | BPNG | https://www.bankpng.gov.pg/about-us/our-objectives | Objectives; check current wording |
| BPNG-06 | BPNG | https://www.bankpng.gov.pg/financial-markets/domestic-money-and-bond-market-operations-and-development/government-treasury-bills/government-treasury-bills | Treasury bills; dated yield table needed |
| BPNG-07 | BPNG | https://www.bankpng.gov.pg/financial-markets/domestic-money-and-bond-market-operations-and-development/bpng-bill-bpng-bond/treasury-bill-and-treasury-bond-tap-facility | Tap facility; check current process |
| PNGX-01 | PNGX | https://www.pngx.com.pg/companies/listed-companies/ | Listings; dated snapshot, recheck |
| PNGX-02 | PNGX | https://www.pngx.com.pg/about-pngx/ | Background/market data; discrepancy noted |
| SCPNG-01 | SCPNG | https://www.scpng.gov.pg/ | Regulation; exact notices needed |
| SCPNG-02 | SCPNG | https://www.scpng.gov.pg/png-national-stock-exchange/ | Exchange/broker information; verify |
| TREASURY-01 | PNG Treasury | https://www.treasury.gov.pg/debt-2/ | Debt; exact dated report needed |
| NSO-01 | NSO | https://www.nso.gov.pg/statistics/economy/international-merchandise-trade/2024-release/ | 2024 trade; verify tables |
| NSO-02 | NSO | https://www.nso.gov.pg/statistics/economy/international-merchandise-trade/2025-release | 2025 trade; verify contents |
| IMF-01 | IMF | https://www.imf.org/ | Forecasts/FX; exact country report needed |
| WB-01 | World Bank | https://www.worldbank.org/ | Analysis; exact report needed |
| WB-02 | World Bank | https://data.worldbank.org/country/papua-new-guinea | Indicators; check metadata |
| WTO-01 | WTO | https://www.wto.org/ | Trade review; exact table needed |

## 29. Provenance and version history

**Version 1.0 — reconstructed working master**
- Consolidates findings preserved in prior project context.
- Baseline: 4 October 2026.
- Original dossier, Perplexity handover and gap-verification files were not available during reconstruction.
- Companion files in the recovery package are reconstructed replacements, not exact recovered originals.
- Multiple figures remain subject to source-level verification.
- This version is not fully audited or publication-ready.

## 30. Publication verification checklist

- [ ] Recheck PNGX listings and market-capitalisation date/basis.
- [ ] Verify latest BPNG KFR and CRR.
- [ ] Verify actual inflation/GDP and separate them from forecasts.
- [ ] Verify foreign reserves and public debt.
- [ ] Verify Treasury bill yields with date, maturity and method.
- [ ] Recheck licensed banks and other institutions.
- [ ] Verify current authorised brokers.
- [ ] Validate financial-inclusion indicators and definitions.
- [ ] Keep mobile-money accounts separate from active users/people.
- [ ] Verify women's financial-access evidence.
- [ ] Resolve or qualify deposit-insurance statements.
- [ ] Recheck virtual-asset laws and notices.
- [ ] Extract current superannuation and insurance statistics.
- [ ] Review scam claims and avoid unsupported prevalence numbers.
- [ ] Check source links, document dates and tables.
- [ ] Confirm forecasts are not presented as actual outcomes.
- [ ] Remove unsupported personalised advice and guaranteed-return claims.
- [ ] Obtain owner approval before the next project phase.
